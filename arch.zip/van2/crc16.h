#ifndef VANITYGEN_PLUSPLUS_CRC16_H
#define VANITYGEN_PLUSPLUS_CRC16_H

unsigned short crc16(const unsigned char *in, unsigned short length);

#endif //VANITYGEN_PLUSPLUS_CRC16_H
